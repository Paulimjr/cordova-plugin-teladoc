//
//  sdk.h
//  sdk
//
//  Created by Jared Kanter on 7/6/16.
//  Copyright © 2016 Teladoc Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for sdk.
FOUNDATION_EXPORT double sdkVersionNumber;

//! Project version string for sdk.
FOUNDATION_EXPORT const unsigned char sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <sdk/PublicHeader.h>

#import <Teladoc/TeladocSDK.h>
