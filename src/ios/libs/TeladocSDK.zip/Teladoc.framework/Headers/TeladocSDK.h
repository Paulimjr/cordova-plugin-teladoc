/*!
 @header TeladocSDK.h
 @description Teladoc Mobile SDK
 @copyright 2016 Teladoc Inc. All rights reserved.
 @version 3.27.2
 
 CHANGE LOG
 - v3.27.4
 -- WCAG Updatess
 - v3.27.2
 -- Added Member Satisfaction Survey for applicable clients
 -- WCAG Updatess
 - v3.27.1
 -- Video SDK Rollback
 - v3.27
 -- WCAG Updates
 -- Calendar timeslots issue fixed
 - v3.26
 -- Moved Swift 4.2 -> Swift 5
 -- Resolved logout bug for service methods returning 401
 -- WCAG Updates
 - v3.25.1
 -- Added Teladoc International Access to SDK
 -- Updated Header filenames to fix xCode warning.
 ---- New usage is:  @import Teladoc;
 - v3.25
 -- Replaced NSCoding with NSSecureCoding
 -- WCAG Updates
  - v3.24.2
 -- WCAG Updates
 - v3.24.1
 -- Fixed issue with PayPal payments
 -- Resolved bug where credentials were getting improperly cleared after failed geocampaigns call
 -- WCAG Updates
 - v3.23.8
 -- Fixed iOS 13 HTML->NSAttributedString rendering issue with custom fonts
 -- Fixed Time Slot functionality when large number of times available
 - v3.23.7
 -- Added Time Slot Scheduling Functionality
 -- Improved WCAG Compliance
 - v3.23.6
 -- Built with xCode 11
 - v3.23.5
 -- Added Pencil Icon
 - v3.23.4
 -- Improved WCAG Compliance
 -- New Event Tracking
 -- iOS 13 Modal Handling
 - v3.23.3
 -- General Updates throughout SDK
 - v3.22.16
 -- Removed unused CoreBluetooth Framework that was requiring Info.plist item NSBluetoothAlwaysUsageDescription
 - v3.22.15
 -- Updated SDK for our Video Provider to fix iOS 13 Crash
 - v3.22.14
 -- Fixed Dashboard background refresh issue
 -- Fixed Enhanced Scheduling date request/time
 -- Improved analytics tracking capabilities
 -- Removed UIWebView from Framework
 - v3.22.13
 -- Fixed Calendar scroll between months
 -- Fixed error callback
 -- Removed attributed text from accessibility reader
 -- Doubled refresh time when accessiblity is on
 - v3.22.12
 -- Updated Calendar View keyboard functionality
 -- Improved Accessibility for Calendar View
 -- Fixed Accessibility playing elements behind the view
 -- Fixed Calendar popup going to background
 -- Fixed Accessibiliy bug for occasional dropdown items
 - v3.22.11
 -- Added front end validation to enhanced date/time picker
 -- Fixed date/time picker crash
 -- Fixed bug with timer for dashboard video button on/off switch
 -- Allow centering of html formatted text fields
 - v3.22.10
 -- Fixed Swift App Compatability
 -- Fixed video demo mode functionality
 - v3.22.9
 -- Fixed Map View alignment when using custom header
 -- Fixed video demo mode functionality for Dashboard
 - v3.22.8
 -- Improved User Interface for Enhanced Scheduling
 -- Fixed bug with strings translations file
 -- Enhancements to Video Logging Functionality
 - v3.22.7
 -- Added HUD spinner functionality to Dashboard
 -- Improved User Interface for Enhanced Scheduling
 -- Added functionality to add scheduled consult to iPhone calendar (requires Privacy setting in Info.plist)
 - v3.22.6
 -- Added functionality for enhanced scheduling
 -- Fully integrated Teladoc Web Browser removing 3rd party dependency
 - v3.22.5
 -- Fixed bug when scheduling BH consult where time was not within 72hrs if selected the most recent day
 -- Fixed Agreements button text color
 - v3.22.4
 -- Added Theme Setting
 -- Errors now set top and bottom border colors
 -- Updated icons throughout app to use primary color
 -- All API Calls now return NSURLSessionDataTask so you can manipulate the request as necessary
 - v3.22.3
 -- Improved Error Handling
 -- Added Cancel Consult API Call
 -- Added Reschedule Workflow
 -- Added canceling of most recent teladoc request
 - v3.22.2
 -- Added Back Care
 -- Added post registration routes
 - v3.22.1
 -- Fixed Location Services Bug
 -- Fixed iOS 10 Color Bug
 -- Changed to Custom Web View Controller for most areas
 - v3.22
 -- Added localization support to SDK
 - v3.21.5
 -- Removed navigationBarTintColor
 - v3.21.4
 -- Fixed iOS 10 Error Message Bug
 - v3.21.3
 -- Moved SDK Preprocessor Macros to Feature Toggles
 -- Fixed bug around webviews for agreements
 -- Added Error Text Color as customizable
 -- Updated Build System for CLI
 -- Removed unnecessary files for Speech Recognizer and MPMoviePlayerController for App Submission
 -- Moved all images inside Bundle for more efficient distribution
 - v3.21.1
 -- Fixed SDK Video Room dismissing entire Dashboard
 -- General Bug Fixes
 - v3.21
 -- Added International Functionality if group has access
 -- Removed BlocksKit dependency to fix Swift Recursion
 */

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, TDRegistrationStatus)
{
  /** Login has not been attempted and the member's registration status is unknown */
  TDRegistrationStatusUnknown,
  /** Member is valid, but not registered */
  TDRegistrationStatusNotRegistered,
  /** Member is not valid */
  TDRegistrationStatusNotValid,
  /** Member is valid, registered and has been logged in */
  TDRegistrationStatusRegistered
};

typedef NS_ENUM(NSInteger, TDRoute)
{
  /** Login has not been attempted and the member's registration status is unknown */
  TDRouteDashboard,
  TDRouteRequestConsult,
  TDRouteMessageCenter,
  TDRouteMedicalInfo,
  TDRouteConsultList,
  TDRouteAccountSettings,
  TDRouteBackCare,
  TDRouteExpertMedicalOpinion,
  TDRouteFindBestDoctor
};

extern NSString *const TeladocVideoRoomWillAppear;
extern NSString *const TeladocVideoRoomWillDisappear;

extern NSString *const TeladocStatusProgress;
extern NSString *const TeladocStatusBackButton;
extern NSString *const TeladocStatusCloseButton;
extern NSString *const TeladocStatusNavLevel;

@interface Teladoc : NSObject
/*!
 @brief Singleton to access Teladoc services
 @return Initialized instance of Teladoc
 */
+ (Teladoc *)apiService;

/*!
 @brief Initialize an instance of the Teladoc SDK with your API Key. A Production and Development key is provided to you by Teladoc. You are able to choose between production or non production environment.
 @param apiKey The API Key provided to by Teladoc
 @param isProduction A boolean value that decides whether to hit production or dev server
 */
+ (void)initWithApiKey:(NSString *)apiKey isProd:(BOOL)isProduction;

/*!
 @brief Initialize an instance of the Teladoc SDK with your API Key. A Production and Development key is provided to you by Teladoc. You are able to choose between production or non production environment.
 @param apiKey The API Key provided to by Teladoc
 @param isProduction A boolean value that decides whether to hit production or dev server
 @param environment A string value that sets the specific Environment for the Teladoc Server
 */
+ (void)initWithApiKey:(NSString *)apiKey isProd:(BOOL)isProduction environment:(NSString *)environment;

/*!
 @brief A string value showing the version of the sdk
 */
+ (NSString *)version;

/*!
 @brief A string value showing the environment the SDK is currently pointing too
 */
- (NSString *)environment;

#pragma mark - Property Objects
/*!
 @brief A boolean value allowing us to set Video Demo Mode functionality so all video consults connect to the Video Demo App.
 Default value is NO
 */
@property (nonatomic,assign,getter=isVideoDemoModeActive) BOOL videoDemoMode;

/*!
 @brief A read-only value that states what environment you are in.  Used for development mode only.
 */
@property (nonatomic,assign,readonly) NSString *environment;

/*!
 @brief A string value with your custom theme. Provided by Teladoc
 */
@property (nonatomic,strong) NSString *theme;

/*!
 @brief A string value for your app's regular font name
 */
@property (nonatomic,strong) NSString *regularFont;

/*!
 @brief A string value for your app's light font name
 */
@property (nonatomic,strong) NSString *lightFont;

/*!
 @brief A string value for your app's bold font name
 */
@property (nonatomic,strong) NSString *boldFont;

/*!
 @brief A string value for your app's medium font name
 */
@property (nonatomic,strong) NSString *mediumFont;

/*!
 @brief A string value for your app's italic font name
 */
@property (nonatomic,strong) NSString *italicFont;

/*!
 @brief A string value for your app's medium/italic font name
 */
@property (nonatomic,strong) NSString *mediumItalicFont;

/*!
 @brief A string value for your app's bold/italic font name
 */
@property (nonatomic,strong) NSString *boldItalicFont;

/*!
 @brief A string value for your app's bold/light font name
 */
@property (nonatomic,strong) NSString *lightItalicFont;

/*!
 @brief A UIColor object for your company primary color
 */
@property (nonatomic,strong) UIColor *primaryColor;

/*!
 @brief A UIColor object for your company secondary color
 */
@property (nonatomic,strong) UIColor *secondaryColor;

/*!
 @brief A UIColor object for your company tertiary color
 */
@property (nonatomic,strong) UIColor *tertiaryColor;

/*!
 @brief A UIColor object for your error color
 */
@property (nonatomic,strong) UIColor *errorColor;

/*!
 @brief A UIColor object for your error text color
 */
@property (nonatomic,strong) UIColor *errorTextColor;

#pragma mark - Header Methods
/*!
 @brief A custom UIView object that will be put in place of our header
 */
@property (nonatomic,strong) UIView *customHeaderView;

/*!
 @brief A UIColor object for the status bar
 */
@property (nonatomic,strong) UIColor *statusBarColor;

/*!
 @brief A boolean stating whether we should show the TDHeader.  Defaults to false and only used if Custom Header View is set
 */
@property (nonatomic,assign) BOOL showTDHeader;

/*!
 @brief A callback block that is initiated whenever the status of the header has changed.  This is used primarily when a custom
 header is used in order to show or hide specific information about the SDK's state in the workflow.  It sends back the following params in the progress dictionary
 - TeladocStatusProgress(CGFloat);
 - TeladocStatusBackButton(BOOL);
 - TeladocStatusCloseButton(BOOL);
 
 */
@property (nonatomic, copy) void (^headerStatusChanged)(NSDictionary *progress);

/*!
 @brief This function navigates the Teladoc SDK back 1 screen.  Use if you have a custom header set when your back button is pressed
 */
- (void)navigateBack;

/*!
 @brief This function closes the Teladoc SDK if the close button is present.  Use if you have a custom header set when your close button is pressed
 */
- (void)navigateClose;

#pragma mark - Callback Blocks
/*!
 @brief A callback block that is initiated whenever an event is triggered in the application.  This sends along the type and name of event in the eventInfo dictionary
 */
@property (nonatomic, copy) void (^trackingEventTriggered)(NSDictionary *eventInfo);

/*!
 @brief A callback block that is initiated whenever an error is triggered in the application.  This sends along the error message and whether the user
 is logged in or not in the errorInfo dictionary
 */
@property (nonatomic, copy) void (^errorTriggered)(NSDictionary *errorInfo);


#pragma mark - Authentication Methods
/*!
 @brief Log into the Teladoc system as a specific member
 @param token The SSO Token that is used to log into the Teladoc system as a member. It is created by combining a few parameters about the member and your company.  That combination is then encrypted by your RSA Public Key.
 @param completion A block object that returns whether the login was successful or not.
 */
- (void)loginWithToken:(NSString *)token completion:(void (^)(BOOL completed, id error))completion;

/*!
 @brief Log the member out of the teladoc system
 */
- (void)logout;

/*!
 @brief Returns a boolean telling you whether a member is logged into the system
 @return A boolean value stating the members logged in status
 */
- (BOOL)isLoggedIn;

/*!
 @brief Returns a boolean telling you whether the member needs registration
 @return A boolean value stating whether a member needs registration
 */
- (TDRegistrationStatus)registrationStatus;

#pragma mark - Service Methods
/*!
 @brief Returns the consults that a member has scheduled for their account
 @param completion A block that returns an array of consults the member has scheduled.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)getConsultsWithCompletion:(void (^)(BOOL completed, NSArray *consults, NSError *error))completion;

/*!
 @brief Returns the messages the member has in their message center
 @param completion A block that returns all messages for member.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)getMessagesWithCompletion:(void (^)(BOOL completed, NSArray *messages, NSError *error))completion;

/*!
 @brief Cancels a visit that the member has scheduled
 @param consultID A string for the consult ID that you will be cancelling
 @param completion A block that returns all messages for member.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)cancelConsult:(NSString *)consultID completion:(void (^)(BOOL completed, NSError *error))completion;

/*!
 @brief Makes a call to the system to return the URL for our Symptom Checker.
 @param completion A block that states whether the call was successfull or not. It also returns a dictionary with a data object containing our Symptom Checker.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)symptomCheckerWithCompletion:(void (^)(BOOL completed, NSDictionary *data, NSError *error))completion;

/*!
 @brief Makes a call to the system to return the token for our Back Care functionality.
 @param completion A block that states whether the call was successfull or not. It also returns a dictionary with a data object containing a one-time sesion token which can be used to load Back Care in a Web Browser.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)backCareUrlWithCompletion:(void (^)(BOOL completed, NSDictionary *data, NSError *error))completion;


#pragma mark - Workflows
/*!
 @brief Makes a call to the system to start the Dashboard workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Add Image functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)dashboardWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Dashboard workflow.
 @param options A dictionary of options that we want to send up to the workflows
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Add Image functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)dashboardWithOptions:(NSDictionary *)options completion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to load a video chat with the provider.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the video chat functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)startVideoConsultWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to load a video chat with the provider while providing the consult to begin.
 @param consultID The Consult ID that we want to begin
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the video chat functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)startVideoConsultWithID:(NSString *)consultID completion:(void (^)(BOOL completed,UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to load a video chat with the provider while providing the consult to begin.
 @param token The token that opens up a video room.  This is generally sent through Push Notifications and is used for deep linking
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the video chat functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)startVideoConsultWithToken:(NSString *)token completion:(void (^)(BOOL completed,UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Request A Consult workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Request A Consult functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)requestConsultWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Account Settings workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Account Settings functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)accountSettingsWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Message Center workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Message Center functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)messageCenterWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the consult list workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Consult List functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)consultListWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Medical Info workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the members Medical Information functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)medicalInfoWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Add Image workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Add Image functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)imageUploadWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Consult Reschedule workflow.
 @param consultID Consult ID string of the visit that you are looking to reschedule
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Consult Reschedule functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)rescheduleConsult:(NSString *)consultID completion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Registration workflow with Token login.
 @param token Token that will be associated with user for SSO login.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Registration functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)registrationWithToken:(NSString *)token andCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Registration workflow with Token login and send the user to a specific flow after registration is complete.
 @param token Token that will be associated with user for SSO login.
 @param route TDRoute that will be called after registration is complete.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Registration functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)registrationWithToken:(NSString *)token andPostRegRoute:(TDRoute)route andCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to retrieve a message.
 @param messageData data for message returned from getMessageWithCompletion:
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Message functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)messageWithData:(NSDictionary *)messageData andCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to retrieve a consult details.
 @param consultID id for consult returned from getConsultsWithCompletion:
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Message functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)consultDetailsWithID:(NSString *)consultID andCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Back Care workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Back Care functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)backCareWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Expert Medical Opinion workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Expert Medical Opinion functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)expertMedicalOpinionWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start the Find Best Doctor workflow.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the Find Best Doctor functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)findBestDoctorWithCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

#pragma mark - Helper Methods
/*!
 @brief Makes a call to the system to start a specific workflow.
 @param route TDRoute object for the route that you are calling.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the specific route functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)callRoute:(TDRoute)route withCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

/*!
 @brief Makes a call to the system to start a specific workflow.
 @param route TDRoute object for the route that you are calling.
 @param token Token that will be associated with user for SSO login.
 @param completion A block that states whether the call was successfull or not. It also returns the ViewController with the specific route functionality.
 @return An NSURLSessionDataTask object that allows you to access details about the request and cancel it if necessary
 */
- (NSURLSessionDataTask *)callRoute:(TDRoute)route withToken:(NSString *)token andCompletion:(void (^)(BOOL completed, UIViewController *viewController, NSError *error))completion;

@end
